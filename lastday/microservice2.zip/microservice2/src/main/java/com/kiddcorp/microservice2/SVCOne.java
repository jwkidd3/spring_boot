package com.kiddcorp.microservice2;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("gateway")
public interface SVCOne {
	
	@RequestMapping("/microservice/greet")
	public String greet();

}
