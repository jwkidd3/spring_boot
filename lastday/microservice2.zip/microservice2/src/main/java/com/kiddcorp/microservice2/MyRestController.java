package com.kiddcorp.microservice2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {
	
	@Value("${app.greeting}")
	private String greeting;
	
	@Value("${server.port}")
	private String port;
	
	@Autowired
	private SVCOne svc;
	
	@RequestMapping("/greet")
	public String m1() {
		return greeting + "->" +port;
	}
	
	@RequestMapping("/getone")
	public String m2() {
		return svc.greet();
	}

}
